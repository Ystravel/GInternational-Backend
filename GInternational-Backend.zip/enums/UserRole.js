export default {
  USER: 0,
  ADMIN: 1,
}

// 角色名稱對照表
export const roleNames = {
  0: '一般員工',
  1: '管理者',
}
