import FormTemplate from '../models/formTemplate.js'
import { StatusCodes } from 'http-status-codes'
import AuditLog from '../models/auditLog.js'

// 創建表單模板
export const create = async (req, res) => {
  try {
    console.log('收到的資料:', req.body)

    if (!req.body.name || !req.body.type || !req.body.componentName) {
      return res.status(StatusCodes.BAD_REQUEST).json({
        success: false,
        message: '缺少必填欄位',
        missingFields: {
          name: !req.body.name,
          type: !req.body.type,
          componentName: !req.body.componentName
        }
      })
    }

    const result = await FormTemplate.create({
      name: req.body.name,
      type: req.body.type,
      componentName: req.body.componentName
    })

    await AuditLog.create({
      operatorId: req.user._id,
      operatorInfo: {
        name: req.user.name,
        userId: req.user.userId
      },
      action: '創建',
      targetId: result._id,
      targetInfo: {
        name: result.name
      },
      targetModel: 'formTemplates',
      changes: {
        表單名稱: {
          from: null,
          to: result.name
        },
        表單類型: {
          from: null,
          to: result.type
        },
        組件名稱: {
          from: null,
          to: result.componentName
        }
      }
    })

    res.status(StatusCodes.OK).json({
      success: true,
      message: '表單模板建立成功',
      result
    })
  } catch (error) {
    console.error('創建失敗:', error)
    if (error.name === 'ValidationError') {
      const key = Object.keys(error.errors)[0]
      const message = error.errors[key].message
      res.status(StatusCodes.BAD_REQUEST).json({
        success: false,
        message,
        validationError: error.errors
      })
    } else if (error.name === 'MongoServerError' && error.code === 11000) {
      res.status(StatusCodes.CONFLICT).json({
        success: false,
        message: '表單名稱已存在'
      })
    } else {
      res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
        success: false,
        message: '未知錯誤',
        error: error.message
      })
    }
  }
}

// 取得所有表單模板
export const getAll = async (req, res) => {
  try {
    const itemsPerPage = parseInt(req.query.itemsPerPage) || 10
    const page = parseInt(req.query.page) || 1

    const [result] = await FormTemplate.aggregate([
      { $sort: { name: 1 } },
      {
        $facet: {
          metadata: [{ $count: 'total' }],
          data: [
            { $skip: (page - 1) * itemsPerPage },
            { $limit: itemsPerPage }
          ]
        }
      }
    ])

    const totalItems = result.metadata[0]?.total || 0

    res.status(StatusCodes.OK).json({
      success: true,
      message: '',
      result: {
        data: result.data,
        totalItems,
        itemsPerPage,
        currentPage: page
      }
    })
  } catch (error) {
    res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
      success: false,
      message: '未知錯誤'
    })
  }
}

// 編輯表單模板
export const edit = async (req, res) => {
  try {
    const original = await FormTemplate.findById(req.params.id)
    if (!original) throw new Error('NOT FOUND')

    const result = await FormTemplate.findByIdAndUpdate(
      req.params.id,
      {
        name: req.body.name,
        type: req.body.type,
        componentName: req.body.componentName
      },
      { new: true, runValidators: true }
    )

    await AuditLog.create({
      operatorId: req.user._id,
      operatorInfo: {
        name: req.user.name,
        userId: req.user.userId
      },
      action: '修改',
      targetId: result._id,
      targetInfo: {
        name: result.name
      },
      targetModel: 'formTemplates',
      changes: {
        表單名稱: {
          from: original.name,
          to: result.name
        },
        表單類型: {
          from: original.type,
          to: result.type
        },
        組件名稱: {
          from: original.componentName,
          to: result.componentName
        }
      }
    })

    res.status(StatusCodes.OK).json({
      success: true,
      message: '表單模板修改成功',
      result
    })
  } catch (error) {
    if (error.name === 'ValidationError') {
      const key = Object.keys(error.errors)[0]
      const message = error.errors[key].message
      res.status(StatusCodes.BAD_REQUEST).json({
        success: false,
        message
      })
    } else if (error.message === 'ID') {
      res.status(StatusCodes.BAD_REQUEST).json({
        success: false,
        message: '表單模板 ID 格式錯誤'
      })
    } else if (error.message === 'NOT FOUND') {
      res.status(StatusCodes.NOT_FOUND).json({
        success: false,
        message: '找不到表單模板'
      })
    } else {
      res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
        success: false,
        message: '未知錯誤'
      })
    }
  }
}

// 刪除表單模板
export const remove = async (req, res) => {
  try {
    const result = await FormTemplate.findById(req.params.id)
    if (!result) throw new Error('NOT FOUND')

    await result.deleteOne()

    await AuditLog.create({
      operatorId: req.user._id,
      operatorInfo: {
        name: req.user.name,
        userId: req.user.userId
      },
      action: '刪除',
      targetId: result._id,
      targetInfo: {
        name: result.name
      },
      targetModel: 'formTemplates',
      changes: {
        表單名稱: {
          from: result.name,
          to: null
        }
      }
    })

    res.status(StatusCodes.OK).json({
      success: true,
      message: '表單模板刪除成功'
    })
  } catch (error) {
    if (error.message === 'ID') {
      res.status(StatusCodes.BAD_REQUEST).json({
        success: false,
        message: '表單模板 ID 格式錯誤'
      })
    } else if (error.message === 'NOT FOUND') {
      res.status(StatusCodes.NOT_FOUND).json({
        success: false,
        message: '找不到表單模板'
      })
    } else {
      res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
        success: false,
        message: '未知錯誤'
      })
    }
  }
}

// 取得單個表單模板
export const getById = async (req, res) => {
  try {
    const result = await FormTemplate.findById(req.params.id)

    if (!result) {
      return res.status(StatusCodes.NOT_FOUND).json({
        success: false,
        message: '找不到表單模板'
      })
    }

    res.status(StatusCodes.OK).json({
      success: true,
      message: '',
      result
    })
  } catch (error) {
    if (error.name === 'CastError') {
      res.status(StatusCodes.BAD_REQUEST).json({
        success: false,
        message: '表單模板 ID 格式錯誤'
      })
    } else {
      res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
        success: false,
        message: '未知錯誤'
      })
    }
  }
}

// 添加搜尋方法
export const search = async (req, res) => {
  try {
    console.log('收到搜尋請求')
    console.log('查詢參數:', req.query)

    const query = {}

    if (req.query.type) {
      query.type = req.query.type
      console.log('添加類型條件:', query.type)
    }

    console.log('最終查詢條件:', query)

    const result = await FormTemplate.find(query)
      .sort({ name: 1 })

    console.log('查詢結果:', result)

    res.status(StatusCodes.OK).json({
      success: true,
      message: '',
      result
    })
  } catch (error) {
    console.error('搜尋失敗，錯誤:', error)
    res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
      success: false,
      message: '搜尋失敗'
    })
  }
}
